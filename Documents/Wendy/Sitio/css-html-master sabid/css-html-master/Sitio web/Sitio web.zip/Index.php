<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body id="Website">
    <p class="parrafos">
       <span>Hola</span>, Cancion.
       <span>Hola <strong>Bello</strong> </span>
    </p>
    <img src="" alt="Soy una imagen">
    
    ?php
    echo "Aprendiendo a Programar";
    ?>


</body>
</html>